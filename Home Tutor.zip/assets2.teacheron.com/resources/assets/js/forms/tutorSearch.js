//console.log("tutorSearch.js loaded")
//var country = '';
//var countryShort = '';
//var countryLong = '';
var searchAddress = ''; // represents the formatted address which can be used to compare
var placeId = '';
var area_address = ''; // csv address after removing junk and duplicates.

// used to save locationId comes from locationAjax, reset it every ajax call.
var locationUrlIdDb = '';
var isLocSearchGoing = false;
//var levelUrlByIdJson = '';
var isHomePage = location.pathname == getAppContext();

var URL_VAL = {
    FIND_OR_SAVE_SUBJECT_SEARCHES: getAppContext() + 'find-or-save-subject-searches',
    LOCATION_SAVE_COMMON: getAppContext() + 'location-save-tutor-or-job-search',
    SUBJECT_SEARCH_AJAX: getAppContext() + 'subject-search-ajax'
};





var contains = function(needle) {
    var findNaN = needle !== needle;
    var indexOf;
    if (!findNaN && typeof Array.prototype.indexOf === 'function') {
        indexOf = Array.prototype.indexOf;
    } else {
        indexOf = function(needle) {
            var i = -1,
                index = -1;
            for (i = 0; i < this.length; i++) {
                var item = this[i];
                if ((findNaN && item !== item) || item === needle) {
                    index = i;
                    break;
                }
            }
            return index;
        };
    }
    return indexOf.call(this, needle) > -1;
};


var locationIdSearch = 0;
var setLocationIdForSearch = function(val) {
    if (isNotBlank(val)) {
        locationIdSearch = val;
        locationUrlIdDb = val;
        // locationIdSearch = base62ToInt(val);
        // locationUrlIdDb = locationIdSearch;
    }
}



//$('.').click(function(){
$(document).on("click ", ".lockForSearch", function() {
    lockForSearch();
});

function lockForSearch() {
    startSearchSpinner();
    if (isLocSearchGoing == true) {
        setTimeout(lockForSearch, 100);
        //console.log('------ wait------',isLocSearchGoing);
    } else {
        //console.log('------ exiting------',isLocSearchGoing);
        // isLocSearchGoing = false;
        startSearching();
    }
}

function startSearching() {
    //console.log('--- startSearching --- ');

    // Below two is used to validation subject name.
    var subject = document.getElementById("subjectAutocomplete").value;
    var subjectId = document.getElementById('subjectId').value;
    var subjectSearchId = document.getElementById('subjectSearchId').value;

    if (locationIdSearch == 0 && !document.getElementById("region_lat").value && document.getElementById("autocomplete").value) {
        //		console.log("locationIdSearch",locationIdSearch,"region_lat",document.getElementById("region_lat").value,"autocomplete",document.getElementById("autocomplete").value);
        alert('Please select area from suggested options as you type.');
        document.getElementById("autocomplete").value = '';
        document.getElementById("autocomplete").focus();
        stopSearchSpinner();
        return;
    }
    // subject validation : name is entered but we dont have id means that subject is not valid
    /*else if(isNotBlank(subject) */
    /*&& isBlank(subjectId)*/
    /*){
            alert('Please enter valid subject to Search.');
            document.getElementById("subjectAutocomplete").value='';
            return;
        }*/
    else {

        /*console.log('--- start spinner --- ');
        startSearchSpinner();
        lockForSearch();
        console.log('--- lock complete--- ');*/

        var showUrl = '';
        var method = document.getElementById("method").value;
        var subject = '';
        var subjectName = document.getElementById("subjectAutocomplete").value;
        var subjectUrl = document.getElementById("subjectUrl").value;
        var subjectSearchId = document.getElementById('subjectSearchId').value;
        var isSubjectFound = false; // adding variable to add low and high level filter


        if (isNotBlank(subjectUrl)) {
            subject = subjectUrl;
            isSubjectFound = true;
        } else if (isNotBlank(subjectName)) { // common for both Subject Name && Subject Searches Name
            subject = getSubjectUrlFromSubjectName(subjectName);
            isSubjectFound = true;
        }

        var target = document.getElementById("target").value;
        var regionLat = document.getElementById("region_lat").value;
        var regionLng = document.getElementById("region_lng").value;

        var pageTitle = '';

        if (target == 'tutors') {
            showUrl = 'tutors';
            pageTitle = 'Tutors';
        } else if (target == 'jobs') {
            showUrl = 'tutor-jobs';
            pageTitle = 'Tutor Jobs';
        }

        var methodSubjectShowUrl = (method) + '-' + subject.toLowerCase() + '-';

        if (method == 'online') {
            var methodSubjectPageTitle = 'Online ' + titleCase(subject) + ' ';
        } else {
            var methodSubjectPageTitle = titleCase(subject) + ' ' + titleCase(method);
        }



        showUrl = methodSubjectShowUrl + showUrl;
        pageTitle = methodSubjectPageTitle + ' ' + pageTitle;

        if (addressTypeSearched) {
            if (isNotBlank(addressSearchedUrl)) {
                addressSearched = addressSearchedUrl;
            }

            addressSearched = prepareLocationUrl(addressSearched);

            // Special Case : when user search bhattiwadi (in hindi) application url cause issue so adding location id
            if (isBlank(addressSearched) && isNotBlank(locationUrlIdDb)) {
                addressSearched = intToBase62(locationUrlIdDb);
            }

            pageTitle += ' in ' + addressSearched;


            if (addressTypeSearched == 'postal_code' || addressTypeSearched == 'postal_code_prefix') {
                showUrl += '-in-postcode-' + addressSearched + '?lat=' + regionLat + '&lng=' + regionLng;
            } else {
                showUrl += '-in-' + addressSearched.replaceAll(" ", "_") /*+'?placeId='+placeId+''*/ ;
                showUrl = showUrl.toLowerCase();
            }
        }

        //			window.history.pushState("object or string", "Title", "/new-url");

        /** added location Id and subjecId into URL */
        if (isNotBlank(addressSearchedUrl)) {
            // If locationUrl is not blank then do not append locationId
        } else if (isNotBlank(locationUrlIdDb)) {
            //showUrl = showUrl + getUrlSeparator(showUrl)+"l="+intToBase62(locationUrlIdDb);
            showUrl = showUrl + getUrlSeparator(showUrl) + "ul=" + intToBase62(locationUrlIdDb);
        }

        var subjectId = document.getElementById('subjectId').value;
        var subjectUrl = document.getElementById('subjectUrl').value;
        // added this param for level check
        var isSubjectSearchFound = false;

        // If subjectId is not blank and subjectUrl is blank then only add subjectId in search parameter, in rest case search will done by unique subjectUrl
        if (isNotBlank(subjectId) && isNotBlank(subjectUrl)) {
            // do nothing, no need to add s=1 in url
            isSubjectSearchFound = true;
        } else if (isNotBlank(subjectId) && isBlank(subjectUrl)) {
            showUrl = showUrl + getUrlSeparator(showUrl) + "s=" + intToBase62(subjectId);
            isSubjectSearchFound = true;
        } else if (isNotBlank(subjectSearchId)) { /** this is selectedSubject case */
            showUrl = showUrl + getUrlSeparator(showUrl) + "ss=" + intToBase62(subjectSearchId);
        }

        // 07-Mar-21: Keep level filters even subject is not subject or only single level is selected
        if (isNotBlank(levelUrlByIdJson)) {
            var lowLevelId = $("#subjectLowLevelId").val();
            var highLevelId = $("#subjectHighLevelId").val();
            if (isNotBlank(lowLevelId) || isNotBlank(highLevelId)) {
                var levelUrlObj = JSON.parse(levelUrlByIdJson);
                if (isNotBlank(lowLevelId) && isNotBlank(highLevelId)) {
                    if (lowLevelId == highLevelId) {
                        showUrl = showUrl + getUrlSeparator(showUrl) + "level=" + levelUrlObj[lowLevelId];
                    } else {
                        showUrl = showUrl + getUrlSeparator(showUrl) + "ll=" + levelUrlObj[lowLevelId] + "&hl=" + levelUrlObj[highLevelId];
                    }
                } else if (isNotBlank(lowLevelId)) {
                    showUrl = showUrl + getUrlSeparator(showUrl) + "ll=" + levelUrlObj[lowLevelId];
                } else if (isNotBlank(highLevelId)) {
                    showUrl = showUrl + getUrlSeparator(showUrl) + "hl=" + levelUrlObj[highLevelId];
                }
            }
        }

        // If new subject name entered that entry need to go into subject_searches then call ajax first then search it.
        // means new subject is entered whose ID does not exists, save it into DB then search it.
        // this is required for 2nd, 3rd time search
        if (isNotBlank(subject) && isBlank(subjectId) && isNotBlank(subjectSearchId)) {
            showUrl = cleanText(showUrl);
            submitForm(showUrl);
        }
        // this is required to search first time new subject that are not in subject table.
        else if (isNotBlank(subject) && isBlank(subjectId)) {
            //var url = URL_VAL.FIND_OR_SAVE_SUBJECT_SEARCHES+'?subject='+subjectName;
            //$.get(url, function(data) {
            var subjectPostingAjax = $.post(URL_VAL.FIND_OR_SAVE_SUBJECT_SEARCHES, {
                subject: subjectName
            });
            subjectPostingAjax.done(function(data) {
                var dataArr = data.split('@@');
                if (dataArr[0] == 'SUCC_ALIAS_SUB_WITH_URL') {
                    // this is required because from back-end url can be different from subject name so replace that with url
                    var subjectNameToReplace = getSubjectUrlFromSubjectName(subjectName);
                    // added to ignore case, this can happen when searched two times
                    var subNameToReplaceRegEx = new RegExp(subjectNameToReplace, "ig");
                    var actualSubjectUrl = dataArr[1];
                    showUrl = showUrl.replace(subNameToReplaceRegEx, actualSubjectUrl);
                    // case : Alias subject will not be visible and if user type that alias subject and
                    // searched and if its URL is available then dont add ?s=vk e.g. "Cyber Security"
                    showUrl = cleanText(showUrl);
                    submitForm(showUrl);
                } else if (dataArr[0] == 'SUCC_OLDSUB') {
                    var subSearchId = dataArr[1];
                    showUrl = showUrl + getUrlSeparator(showUrl) + "s=" + intToBase62(subSearchId);
                    showUrl = cleanText(showUrl);
                    submitForm(showUrl);
                } else if (dataArr[0] == 'SUCCESS') {
                    var subSearchId = dataArr[1];
                    showUrl = showUrl + getUrlSeparator(showUrl) + "ss=" + intToBase62(subSearchId);
                    showUrl = cleanText(showUrl);
                    submitForm(showUrl);
                } else {
                    alert('An error occurred while processing subject error: \n' + dataArr[1]);
                    stopSearchSpinner();
                }
            });
        } else {
            showUrl = cleanText(showUrl);
            submitForm(showUrl);
        }
    }
};

var removeAllSpecialSymbol = function(inputString) {
    if (isNotBlank(inputString)) {
        return inputString.replace(/(['"~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-').replace(/^(-)+|(-)+$/g, '');
    } else {
        return inputString;
    }
};

var getSubjectUrlFromSubjectName = function(subjectName) {
    var subject = subjectName;
    subject = removeAllSpecialSymbol(subject);
    subject = subject.replaceAll("-", "_");
    return subject;
};


var getUrlSeparator = function(url) {
    if (url.indexOf('?') != -1) {
        return '&';
    } else {
        return '?';
    }
};

var submitForm = function(showUrl) {
    if (isHomePage) {
        var url = getAppContext() + showUrl;
        //console.log('isHomePage -> submitForm()');
        window.location.href = url;
    } else {
        searchLeanAjax(showUrl);
    }
};


function cleanText(text) {
    text = text.replaceAll("--", "-").replaceAll("--", "-").replaceAll("  ", " ").replaceAll("  ", " "); // convert multiple hyphens and spaces in to single
    text = text.replaceAll(" ", "_"); //convert spaces in to underscores
    text = text.trim('-'); //convert spaces in to underscores
    // remove hyphens and spaces from the end
    return text;
}

function titleCase(str) {
    str = str.toLowerCase().split(' ');

    for (var i = 0; i < str.length; i++) {
        str[i] = str[i].split('');
        if (str[i][0]) str[i][0] = str[i][0].toUpperCase();
        str[i] = str[i].join('');
    }
    return str.join(' ');
}

String.prototype.trimLeft = function(charlist) {
    if (charlist === undefined)
        charlist = "\\s";

    return this.replace(new RegExp("^[" + charlist + "]+"), "");
};
String.prototype.trimRight = function(charlist) {
    if (charlist === undefined)
        charlist = "\\s";

    return this.replace(new RegExp("[" + charlist + "]+$"), "");
};
String.prototype.trim = function(charlist) {
    return this.trimLeft(charlist).trimRight(charlist);
};





var saveLocationAjx = function() {

    var address_json = document.getElementById('address_json').value;
    if (address_json != null && address_json != '' && address_json != undefined) {
        //var formData = new FormData($('form')[0]);
        isLocSearchGoing = true;
        $.ajax({
            url: URL_VAL.LOCATION_SAVE_COMMON,
            type: 'POST',
            //data: formData,
            data: $('form#searchLocationForm').serialize(), // this is required if location is like Urtenen-Schönbühl, it will encode it properly and save it.
            dataType: 'text',
            timeout: T_CONSTANTS.AJAX_TIMEOUT,
            //processData: false,

            beforeSend: function() {
                $("#searchBtn").prop('disabled', true);
            },
            complete: function() {
                $("#searchBtn").prop('disabled', false);
            },
            success: function(data) {
                //console.log('----------reply from ajax data:------------',data);
                isLocSearchGoing = false; // false it to get out from infinite loop.
                //console.log('after ajax reply isLocSearchGoing=',isLocSearchGoing);
                if (data != null && data != '') {
                    var arr = data.split('@');
                    if (arr[0] == 'SUCCESS') {
                        //console.log('data',data);
                        //var locationUrlIdDb = arr[1];
                        //startSearching(locationUrlIdDb);
                        locationUrlIdDb = arr[1];
                        addressSearched = arr[2];
                        if (isNotBlank(arr[3])) {
                            addressSearchedUrl = arr[3];
                        } else {
                            addressSearchedUrl = ''; // set blank if url not found, to avoid previous url issue (e.g. Civil lines Delhi & civil line Allahbad)
                        }
                    } else if (arr[0] == 'POSTAL_CODE_FOUND') {
                        addressSearchedUrl = '';
                    } else {
                        //alert('Something went wrong while processing Location, Error is: '+arr[1]);
                        $.miniNoty('Unknown error. Please try again.', 'error')
                    }
                }
            },
            error: function(jqXHR, textStatus, errorMessage) {
                //alert('Something went wrong, please try again.');
                if (isNotBlank(errorMessage) && errorMessage == 'timeout') {
                    openErrorModel('Timeout Occurred', 'Location search timeout error. Please click ok to retry.');
                    $('#errorCloseBtn').click(function() {
                        location.reload();
                    });
                } else {
                    openErrorModel('Unknown error', 'Please click ok to retry.');
                    $('#errorCloseBtn').click(function() {
                        location.reload();
                    });
                }
            }
        });
    } else {
        startSearching();
    }
};

var subjectLinkFlow = function(subId, subNameLink) {

    subNameLink = subNameLink.replaceAll(" ", "_");
    var url = subNameLink + '-tutors?s=' + intToBase62(subId);
    // this is used to change URL
    window.history.pushState({
        "html": '',
        "pageTitle": subNameLink
    }, "", url);
    url = cleanText(url);
    submitForm(url);
};

var locationLinkFlow = function(locationUrlId, locationName) {
    locationName = locationName.replaceAll(" ", "_");
    //var url = 'tutors-in-'+locationName+ '?l='+intToBase62(locationId);
    var url = 'tutors-in-' + locationName + '?ul=' + intToBase62(locationUrlId);
    // this is used to change URL
    window.history.pushState({
        "html": '',
        "pageTitle": locationName
    }, "", url);
    url = cleanText(url);
    submitForm(url);
};

/**
 * When user click on search button spinner button will start and disable button.
 */
var startSearchSpinner = function() {
    $('#spinnerId').show();
    $("#search-icon-anti-spin").hide();
    // disable click event from button to avoid double click while showing loader image.
    $("#searchBtn").unbind("click");
};

var stopSearchSpinner = function() {
    $('#spinnerId').hide();
    $("#search-icon-anti-spin").show();
    // enable click event that are disable earlier.
    $("#searchBtn").bind("click");
};




//****************************** Jquery code to find and replace character for location UTF-8************************************/
var array_a = ['À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'Ā', 'ā', 'Ă', 'ă', 'Ą', 'ą', 'Ć', 'ć', 'Ĉ', 'ĉ', 'Ċ', 'ċ', 'Č', 'č', 'Ď', 'ď', 'Đ', 'đ', 'Ē', 'ē', 'Ĕ', 'ĕ', 'Ė', 'ė', 'Ę', 'ę', 'Ě', 'ě', 'Ĝ', 'ĝ', 'Ğ', 'ğ', 'Ġ', 'ġ', 'Ģ', 'ģ', 'Ĥ', 'ĥ', 'Ħ', 'ħ', 'Ĩ', 'ĩ', 'Ī', 'ī', 'Ĭ', 'ĭ', 'Į', 'į', 'İ', 'ı', 'Ĳ', 'ĳ', 'Ĵ', 'ĵ', 'Ķ', 'ķ', 'Ĺ', 'ĺ', 'Ļ', 'ļ', 'Ľ', 'ľ', 'Ŀ', 'ŀ', 'Ł', 'ł', 'Ń', 'ń', 'Ņ', 'ņ', 'Ň', 'ň', 'ŉ', 'Ō', 'ō', 'Ŏ', 'ŏ', 'Ő', 'ő', 'Œ', 'œ', 'Ŕ', 'ŕ', 'Ŗ', 'ŗ', 'Ř', 'ř', 'Ś', 'ś', 'Ŝ', 'ŝ', 'Ş', 'ş', 'Š', 'š', 'Ţ', 'ţ', 'Ť', 'ť', 'Ŧ', 'ŧ', 'Ũ', 'ũ', 'Ū', 'ū', 'Ŭ', 'ŭ', 'Ů', 'ů', 'Ű', 'ű', 'Ų', 'ų', 'Ŵ', 'ŵ', 'Ŷ', 'ŷ', 'Ÿ', 'Ź', 'ź', 'Ż', 'ż', 'Ž', 'ž', 'ſ', 'ƒ', 'Ơ', 'ơ', 'Ư', 'ư', 'Ǎ', 'ǎ', 'Ǐ', 'ǐ', 'Ǒ', 'ǒ', 'Ǔ', 'ǔ', 'Ǖ', 'ǖ', 'Ǘ', 'ǘ', 'Ǚ', 'ǚ', 'Ǜ', 'ǜ', 'Ǻ', 'ǻ', 'Ǽ', 'ǽ', 'Ǿ', 'ǿ'];
var array_b = ['A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o'];

function replace_accents(val) { //replace for accents catalan spanish and more
    if (isNotBlank(val)) {
        var strArray = val.split("");
        var response = '';
        for (var i = 0; i < strArray.length; i++) {
            var index = array_a.indexOf(strArray[i]);
            if (index != -1) {
                response = response + array_b[index];
            } else {
                response = response + strArray[i];
            }
        }
        return response;
    } else {
        return val;
    }
};

//********************************************************************************** END

var prepareLocationUrl = function(url) {
    // remove special character from locationName e.g. Urtenen-Schönbühl => convertedTo => Urtenen-Schonbuhl
    url = replace_accents(url);
    url = url.replaceAll(",", " ");
    url = url.replaceAll("-", " ");
    url = url.replaceAll("_", " ");
    url = url.replace(/[^a-zA-Z0-9_ ]/g, "");
    url = Trim(url);
    url = replaceMultipleSpacesWithOne(url);
    url = url.replaceAll(" ", "_");
    return url.toLowerCase();
};

// ***************************** This is used for home page only *****************************
function callParticleJsForHomePage() {
    var particleJs = particlesJS('particles-js', {
        "particles": {
            "number": {
                "value": 150,
                "density": {
                    "enable": true,
                    "value_area": 800
                }
            },
            "color": {
                "value": "#ffffff"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 5
                },
                "image": {
                    "src": "img/github.svg",
                    "width": 100,
                    "height": 100
                }
            },
            "opacity": {
                "value": 0.5,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value": 2,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "size_min": 0.1,
                    "sync": true
                }
            },
            "line_linked": {
                "enable": true,
                "distance": 1,
                "color": "#ffffff",
                "opacity": 0.4,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 1,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": false,
                    "mode": "repulse"
                },
                "onclick": {
                    "enable": false,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 10,
                    "line_linked": {
                        "opacity": .5
                    }
                },
                "bubble": {
                    "distance": 100,
                    "size": 40,
                    "duration": 2,
                    "opacity": 8,
                    "speed": 3
                },
                "repulse": {
                    "distance": 200
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true,
        "config_demo": {
            "hide_card": false,
            "background_color": "#b61924",
            "background_image": "",
            "background_position": "50% 50%",
            "background_repeat": "no-repeat",
            "background_size": "cover"
        }
    });
}

// **************** it will excluded from home page and called form tutor and job search page *****************
function callParticleJsExcludeHome() {
    var particleJs = particlesJS('particles-js', {
        "particles": {
            "number": {
                "value": 5,
                "density": {
                    "enable": true,
                    "value_area": 800
                }
            },
            "color": {
                "value": "#16a085"
            },
            "shape": {
                "type": "circle",
                "stroke": {
                    "width": 0,
                    "color": "#000000"
                },
                "polygon": {
                    "nb_sides": 5
                },
                "image": {
                    "src": "img/github.svg",
                    "width": 100,
                    "height": 100
                }
            },
            "opacity": {
                "value": 0.5,
                "random": false,
                "anim": {
                    "enable": false,
                    "speed": 1,
                    "opacity_min": 0.1,
                    "sync": false
                }
            },
            "size": {
                "value": 20,
                "random": true,
                "anim": {
                    "enable": false,
                    "speed": 40,
                    "size_min": 0.1,
                    "sync": false
                }
            },
            "line_linked": {
                "enable": true,
                "distance": 50,
                "color": "#95a5a6",
                "opacity": 0.4,
                "width": 1
            },
            "move": {
                "enable": true,
                "speed": 1,
                "direction": "none",
                "random": false,
                "straight": false,
                "out_mode": "out",
                "attract": {
                    "enable": false,
                    "rotateX": 600,
                    "rotateY": 1200
                }
            }
        },
        "interactivity": {
            "detect_on": "canvas",
            "events": {
                "onhover": {
                    "enable": false,
                    "mode": "repulse"
                },
                "onclick": {
                    "enable": false,
                    "mode": "push"
                },
                "resize": true
            },
            "modes": {
                "grab": {
                    "distance": 400,
                    "line_linked": {
                        "opacity": 1
                    }
                },
                "bubble": {
                    "distance": 400,
                    "size": 40,
                    "duration": 2,
                    "opacity": 8,
                    "speed": 3
                },
                "repulse": {
                    "distance": 200
                },
                "push": {
                    "particles_nb": 4
                },
                "remove": {
                    "particles_nb": 2
                }
            }
        },
        "retina_detect": true,
        "config_demo": {
            "hide_card": false,
            "background_color": "#b61924",
            "background_image": "",
            "background_position": "50% 50%",
            "background_repeat": "no-repeat",
            "background_size": "cover"
        }
    });
}

function initSubjectSearchAutocomplete() {
    $("#subjectAutocomplete").autocomplete({
        source: function(request, response) {
            var obj = {
                "subjectName": $('#subjectAutocomplete').val(),
                "max": 10
            };

            $.ajax({
                type: "POST",
                url: URL_VAL.SUBJECT_SEARCH_AJAX,
                dataType: 'json', // this is required for response json.
                //data: form_data,
                data: JSON.stringify(obj),
                cache: false,
                processData: false,
                //contentType: false,
                contentType: "application/json;charset=utf-8",
                success: function(data) {
                    if (isBlank(data)) {
                        resetSubjectIdAndRelatedData();
                    }
                    response($.map(data, function(item) {
                        return {
                            url: item.url,
                            value: item.value,
                            description: item.description,
                            label: item.label,
                            // 12-Mar-23: Added to that we can get this field.
                            requireLevelInputFromUser: item.requireLevelInputFromUser
                        }
                    }));
                }
            });
        },
        minLength: 1, // search will start after min words.
        select: function(event, ui) { // when user select values set its ID
            event.preventDefault();
            $("#subjectAutocomplete").val(ui.item.label);
            $("#subjectId").val(ui.item.value);
            $("#subjectUrl").val(ui.item.url);
            searchedSubjectNameTmp = ui.item.label;
            //var log = 'Inside select() event: subjectId: '+JSON.stringify(ui.item);
            //console.log(log);
            // 12-Mar-23: If subject comes with level then disabled level option.
            try {
                if (ui.item.requireLevelInputFromUser == false)
                    $(".clsSubjectFilterModalLink").addClass('disabled');
            } catch (e) {

            }
        },
        focus: function(event, ui) {
            event.preventDefault();
            // 22-Apr-22: When user search subject and focus on that then don't make it selected. To improve user experience we are doing this.
            //$("#subjectAutocomplete").val(ui.item.label);
            //$("#subjectId").val(ui.item.value);
            //$("#subjectUrl").val(ui.item.url);
            //searchedSubjectNameTmp = ui.item.label;
            //var log = 'Inside focus() event: subjectId: '+JSON.stringify(ui.item);
            //console.log(log);
        }
    }).data("ui-autocomplete")._renderItem = function(ul, item) {
        //console.log('------- Inside render item ---------- ', item);
        if (item.description) itemDescription = "(" + item.description + ")";
        else itemDescription = "";

        try {
            // 24-Dec-19: If user type 'Java' and did not select subject/focus it then select it by default. Also it fix when
            // user type 'Communications modelling' and later user delete it to 'communications' only then it should work
            var subjectSearchVal = $('#subjectAutocomplete').val();
            if (isNotBlank(subjectSearchVal) && isNotBlank(item.label)) {
                if (subjectSearchVal.trim().toLowerCase() == item.label.trim().toLowerCase()) {
                    $("#subjectId").val(item.value);
                    $("#subjectUrl").val(item.url);
                    searchedSubjectNameTmp = ui.item.label;
                    //var log = 'setting own value subId:'+item.value+", url: "+item.url;
                    //console.log(log);
                    // 12-Mar-23: If subject comes with level then disabled level option.
                    try {
                        if (ui.item.requireLevelInputFromUser == false)
                            $(".clsSubjectFilterModalLink").addClass('disabled');
                    } catch (e) {

                    }
                }
            }
        } catch (e) {}

        return $("<li></li>")
            .data("item.autocomplete", item)
            .append("<div>" + item.label + " <small>" + itemDescription + "</small></div>")
            .appendTo(ul);
    };
}


// ************************ function to adjust window size of subject and location search box ********************
var windowWidthChanged = false;

var windowWidth = $(window).width();
$(window).on('resize', function() {
    if ($(this).width() !== windowWidth) {
        windowWidth = $(this).width();
        windowWidthChanged = true;
        styleTutorOrJobSearchHeader();
    }
});

/*
function styleLevelFilterButton(){
	//	console.log("styleLevelFilterButton");
	$("#levelFilterButton").removeClass("levelFilterButton");
    if($("#onlineHomeLinksUL").outerHeight()>35){
    	$("#levelFilterButton").addClass("levelFilterButton");
    }
}
*/
/*
function displayFormElementsAsBlockForSmallScreens(){
	console.log("displayFormElementsAsBlockForSmallScreens");
    $("#subjectAutocomplete")[0].style.setProperty("width","100%",'important');
    $("#autocomplete")[0].style.setProperty("width","100%",'important');
    $("#searchBtn")[0].style.setProperty("width","100%",'important');
    $("#hidden-xs-search")[0].style.setProperty("display","auto",'important');
	$("#hidden-xs-search").removeClass("hidden-xs");
	isDisplayFormElementsAsBlockForSmallScreens = true;
}
*/
function styleTutorOrJobSearchHeader() {
    //	console.log("----------------------------------------- styleTutorsJobsSearchHeader ----------------------------------------------");
    stylePageHeading();
    styleLevelFilterButton();

    if (window.innerWidth <= displayFormElementsAsBlockScreenWidth) {
        displayFormElementsAsBlockForSmallScreens();
    } else {
        if (windowWidthChanged || window.innerWidth != localStorage.getItem("windowInnerWidth") || $("#searchLocationForm").outerHeight() > 50) {
            styleTutorOrJobSearchInputAndButton();
        }
        /* commenting as not in use		
        		// Set icon
        		try {
        	        var isChrome = !!window.chrome;
        	        var isSafari = window.safari !== undefined;
        	        if(!(isChrome || isSafari)){
        	            //console.log('----- calling js to set width and height ------------- ');
        	            // logic to set searched subject icon (content in css is not supported in IE and firefox that's why use this way)
        	            var iconClass = $("#pageHeading .custom-icon");
        	            var iconClassContent = iconClass.css( 'content' );
        	            if(iconClassContent){
        	                iconImgUrl = iconClassContent.substr(5, iconClassContent.length-7);
        	                maxWidthCustomIcon = $("#pageHeading .custom-icon").css( 'max-width' );
        	                maxHeightCustomIcon = $("#pageHeading .custom-icon").css( 'max-height' );
        	                iconClass.html('<img style="margin-top:-5px; max-width:'+maxWidthCustomIcon+'; max-height:'+maxHeightCustomIcon+';" src="' + iconImgUrl + '" />');
        	            }
        	        }
        	    }catch(e){
        	        console.log('Error: check custom-icon flow.... ');
        	    }
        */
    }
    styleStickyHeaderForTutorOrJobSearch();

    //resetting variables
    windowWidthChanged = false;
}
var triedToActivateStickyHeader = false;

function styleStickyHeaderForTutorOrJobSearch() {
    //console.log(' ------ loaded styleStickyHeaderForTutorOrJobSearch() ------- ');
    var headerTop = 0;
    var fixed = false;
    var header = $("#custom-sticky");
    var dummy = $("#dummy-height-after-header-fixed");
    var pageHeading = $("#pageHeading");
    var searchFilterDiv = $("#searchFilterDiv");


    function unfixHeader() {
        header.removeClass("headerPageScrolled");
        $(".header-fixed").addClass("homeTutorSearchDiv");
        dummy.css("height", 0);
        pageHeading.removeClass("smallHeading no-margin-top").addClass("margin-top-10");
        searchFilterDiv.css("padding", '');
        fixed = false;
    }

    function tryToActivateStickyHeader() {
        if (headerTop == 0)
            headerTop = header.offset().top; // + header.outerHeight();

        if ($(window).scrollTop() > headerTop) {
            if (!fixed && !isDisplayFormElementsAsBlockForSmallScreens) {
                // actual code taken from history.
                dummy.css("height", header.outerHeight());
                header.addClass("headerPageScrolled");
                $(".header-fixed").removeClass("homeTutorSearchDiv");
                pageHeading.addClass("smallHeading no-margin-top").removeClass("margin-top-10");
                searchFilterDiv.css("padding", '3px');
                fixed = true;
                $("#bg-for-fixed-custom-sticky").css("height", header.outerHeight());
            }
        } else {
            if (fixed) {
                unfixHeader();
            }
        }
        triedToActivateStickyHeader = true;
    }

    if (!triedToActivateStickyHeader) tryToActivateStickyHeader();

    if (!isDisplayFormElementsAsBlockForSmallScreens) {
        //		console.log("stickyHeader")
        $(window).scroll(function() {
            tryToActivateStickyHeader();
        });
    } else {
        unfixHeader();
    }
}
//console.log("window.innerWidth",window.innerWidth, "localStoragewindowInnerWidth", localStorage.getItem("windowInnerWidth"));
//console.log("textFieldWidth",textFieldWidth);

function resetStyleTutorOrJobSearchInputAndButton() {
    $("#subjectAutocomplete")[0].style.setProperty("width", "");
    $("#autocomplete")[0].style.setProperty("width", "");
    localStorage.setItem("searchInputWidth", "");
    localStorage.setItem("windowInnerWidth", "");
    $("#searchBtn")[0].style.setProperty("width", "");
    $("#hidden-xs-search").addClass("hidden-xs");
}

function styleTutorOrJobSearchInputAndButton() {
    //	console.log("styleTutorOrJobSearchInputAndButton");
    resetStyleTutorOrJobSearchInputAndButton();
    var textFieldWidth = $("#subjectAutocomplete").width();
    var i;

    i = 0;
    while ($("#searchLocationForm").outerHeight() > 50 && i++ < 20) {
        textFieldWidth = textFieldWidth - 5;
        //console.log(textFieldWidth);
        $("#subjectAutocomplete")[0].style.setProperty("width", textFieldWidth + 'px', 'important');
        $("#autocomplete")[0].style.setProperty("width", textFieldWidth + 'px', 'important');
    }

    i = 0;
    while ($("#searchLocationForm").outerHeight() < 50 && i++ < 20) {
        textFieldWidth = textFieldWidth + 5;
        //console.log(textFieldWidth);
        $("#subjectAutocomplete")[0].style.setProperty("width", textFieldWidth + 'px', 'important');
        $("#autocomplete")[0].style.setProperty("width", textFieldWidth + 'px', 'important');
    }

    textFieldWidth = textFieldWidth - 8;

    if (textFieldWidth >= 140) {
        var width = textFieldWidth + 'px';
        $("#subjectAutocomplete")[0].style.setProperty("width", width, 'important');
        $("#autocomplete")[0].style.setProperty("width", width, 'important');
        localStorage.setItem("searchInputWidth", width);
        localStorage.setItem("windowInnerWidth", window.innerWidth);
        isDisplayFormElementsAsBlockForSmallScreens = false;
    } else {
        displayFormElementsAsBlockForSmallScreens()
    }
}

/*
function stylePageHeading(){
//	console.log("stylePageHeading");
    // resetting previous styles
	$("#pageHeading").css("fontSize", "");
    $("#pageHeading").css("lineHeight", "");
	// // resetting previous styles end
	
    var size = parseInt($("#pageHeading").css('font-size'));
    var lineHeight = 1.357*size + 1.286;
    while($("#pageTitle").outerHeight()>size+lineHeight && size>16 ){
        size = size -1;
        lineHeight = 1.357*size + 1.286;
        $("#pageHeading").css("fontSize", size);
        $("#pageHeading").css("lineHeight", lineHeight+"px");
        
    }
}
*/

function searchLeanAjax(urlWithoutPrefix) {
    var pageUrl = getAppContext() + urlWithoutPrefix;
    var ajaxUrl = getAppContext() + 'search-lean/' + urlWithoutPrefix;
    searchTutorsOrJobsAjax(ajaxUrl, pageUrl, urlWithoutPrefix, true)
};

var searchTutorsOrJobsAjax = function(ajaxUrl, pageUrl, urlWithoutPrefix, isPushState) {
    $.ajax({
        type: "GET",
        cache: false,
        url: ajaxUrl,
        beforeSend: function() {
            $(window).scrollTop(0);
            $("body").addClass("loading");
            $("#searchBtn").prop('disabled', true);
        },
        error: function(jqXHR, textStatus, errorMessage) {
            //alert(ERROR_MSG.AJAX_FAILED_MSG);
            //console.log('Error on searchTutorsOrJobsAjax()');
            $("body").removeClass("loading");
            window.location.href = pageUrl;
        },
        success: function(data) {
            processSearchLeanAjaxResponse(data, urlWithoutPrefix, pageUrl, isPushState);
            $("body").removeClass("loading");
        },
        complete: function() {
            $("#searchBtn").prop('disabled', false);
        }
    });
};

var processSearchLeanAjaxResponse = function(data, urlWithoutPrefix, pageUrl, isPushState) {
    //var obj = JSON.parse(data);
    //$("#tutorRecordsMainDiv").html(data);
    try {
        // before adding any data just delete previously added rating schema
        try {
            $("#localBusinessSchemaDiv").remove();
        } catch (e) {}
        // it will add new rating schema as well. so no need to add it externally.
        $("#tutorOrJobSearchItemList").html(data);


        // once html is set then load tutor image as well
        try {
            $(".lozad-custom-profile-img").each(function() {
                if ($(this).is("img")) {
                    var src = $(this).attr('data-src');
                    $(this).attr('src', src);
                    $(this).show();
                }
            });
        } catch (e) {

        }

        // change page title and url
        updateCurrentPageUrlAndTitle(urlWithoutPrefix, Trim($("#pageHeaderTitleLean").html()), isPushState);
        $("#pageHeading").html($("#pageHeadingLeanDiv").html());
        // once copy done then delete div
        //$("#pageHeadingLeanDiv").remove();

        if ($("#noRecordsFoundCase").val() == 'y') {
            $("#noRecordFoundOnSearchDiv").show();
        } else {
            $("#noRecordFoundOnSearchDiv").hide();
        }

        $("#locationWiseSearchMainDiv").html($("#locationWiseSearchMainDivSearchLean").html());

        $("#paginationSpan").html($("#paginationSpanSearchLean").html());

        // change url in hyperlink of "all", "online", "home" etc
        $(".onlineOrOffLink").attr('href', $(".onlineOrOffLinkAjax").val());
        $(".onlineLinkWithLocation").attr('href', $(".onlineLinkWithLocationAjax").val());
        $(".homeTutorLink").attr('href', $(".homeTutorLinkAjax").val());
        $(".assignmentLink").attr('href', $(".assignmentLinkAjax").val());

        // if user click on RHS locations then populate that name.
        $("#subjectAutocomplete").val($("#subjectAutocompleteSearchLean").val());
        $("#autocomplete").val($("#autocompleteSearchLean").val());
        $("#subjectId").val($("#subjectIdSearchLean").val());
        $("#subjectUrl").val($("#subjectUrlSearchLean").val());
        $("#subjectSearchId").val($("#subjectSearchIdSearchLean").val());
        $("#subjectSearch").val($("#subjectSearchNameSearch").val());
        $("#locationUrl").val($("#locationUrlSearchLean").val());
        $("#method").val($("#searchMethodSearchLean").val());
        resetAddressFields(); // call this after setting location.
        stopSearchSpinner();

        // 12-Mar-23: Disabled level filter button when subject already have internal levels.
        var selectedSubjectRequiredLevelInputFromUser = $("#selectedSubjectRequiredLevelInputFromUser").val();
        if (isNotBlank(selectedSubjectRequiredLevelInputFromUser) && selectedSubjectRequiredLevelInputFromUser == 'false')
            $(".clsSubjectFilterModalLink").addClass('disabled')
        else
            $(".clsSubjectFilterModalLink").removeClass('disabled')


        var method = $("#searchMethodSearchLean").val();
        if (isNotBlank(method)) {
            if (method == 'online') {
                $(".clsOnlineLink").addClass('active').addClass("underline");
            } else if (method == 'home') {
                $(".clsHomeLink").addClass('active').addClass("underline");
            } else if (method == 'assignment') {
                $(".clsAssignmentLink").addClass('active').addClass("underline");
            }
        } else {
            $(".clsAllLink").addClass("active").addClass("underline");
        }


        // reload tooltips that comes through ajax and applied on <li>
        $('li').tooltip();


        // remove old meta info and add new one.
        replaceMetaAfterAjaxSearch();

        // handle corona related message div and chose whether to set/remove data.
        //$("#staySafeFromCoronaDiv").html($("#staySafeFromCoronaDivSearchLean").html());

        // reset location related hidden data
        $("#search_address").html("");
        $("#duplicate").val("");
        $("#region_lat").val($("#region_lat_searchLean").val());
        $("#region_lng").val($("#region_lng_searchLean").val());
        $("#placeId").val($("#placeId_searchLean").val());
        //$("#countryName").val($("#countryName_searchLean").val());
        //$("#countryShortCode").val($("#countryShortCode_searchLean").val());
        $("#address_json").val("");
        $("#locationIdForSearch").val($("#locationIdForSearch_searchLean").val());
        $("#formattedAddress").val("");
        $("#googleLocationUIResponseJson").val("");
        // ----------- calling jquery on load related function -----------
        try {
            var addressTypeSearchedOnLoad = $("#addressTypeSearchedOnLoadSearchLean").val();
            if (isNotBlank(addressTypeSearchedOnLoad))
                setAddressTypeSearchedOnLoad(addressTypeSearchedOnLoad);
        } catch (e) {
            console.log(e);
        }
        // updated searched location name and it's URL otherwise it will show old location data.
        setLocationNameForSearch($("#locationNameJsonSearchLean").val(), $("#locationUrlSearchLean").val());
        setLocationIdOnLoad();
        //newTutorOrJobSearch = true;
        styleTutorOrJobSearchHeader();
    } catch (e) {
        //console.log('processSearchLeanAjaxResponse() failed to process response. ', e);
        window.location.href = pageUrl;
    }
};


//https://www.geeksforgeeks.org/how-to-modify-url-without-reloading-the-page-using-javascript/
var updateCurrentPageUrlAndTitle = function(urlWithoutPrefix, title, isPushState) {
    $("title").html(title);
    urlWithoutPrefix = getAppContext() + urlWithoutPrefix;
    var state = {
        data: $("#tutorOrJobSearchItemList").html(),
        urlPath: urlWithoutPrefix
    };
    if (isPushState) {
        history.pushState(state, title, urlWithoutPrefix);
    } else {
        // when user click on back button then call replaceState otherwise url travel history will not work properly.
        history.replaceState(state, title, urlWithoutPrefix);
    }
};

var replaceMetaAfterAjaxSearch = function() {
    // adding in try catch in case link are not present and don't stop it's next line execution
    try {
        document.querySelector('link[rel="prev"]').remove();
    } catch (e) {}
    try {
        document.querySelector('link[rel="next"]').remove();
    } catch (e) {}
    try {
        document.querySelector('link[rel="canonical"]').remove();
    } catch (e) {}
    try {
        document.querySelector('meta[name="description"]').remove();
    } catch (e) {}
    try {
        document.querySelector('meta[name="ROBOTS"]').remove();
    } catch (e) {}

    try {
        if ($("#urlPrevSearchLean").length) {
            createMetaLink('prev', $("#urlPrevSearchLean").html());
        }
    } catch (e) {
        console.log(e);
    }

    try {
        if ($("#urlNextSearchLean").length) {
            createMetaLink('next', $("#urlNextSearchLean").html());
        }
    } catch (e) {
        console.log(e);
    }

    try {
        if ($("#canonicalSearchLean").length) {
            createMetaLink('canonical', $("#canonicalSearchLean").html());
        }
    } catch (e) {
        console.log(e);
    }

    try {
        if ($("#metaDescSearchLean").length) {
            createMetaTag('description', htmlDecodeEscaptedCharacter($("#metaDescSearchLean").html()));
        }
    } catch (e) {
        console.log(e);
    }

    try {
        if ($("#noindexNofollowSearchLean").length) {
            createMetaTag("ROBOTS", "NOINDEX, NOFOLLOW");
        }
    } catch (e) {
        console.log(e);
    }


    // prepare meta itemprop
    try {
        if ($("#isTutorSearchFlowSearchLean").val() == 'y' && parseInt($("#totalResultsFoundSearchLean").html()) >= 1) {
            try {
                var pageTitle = htmlDecodeEscaptedCharacter($("#pageTitle").html());
                var pageTitleLevelInfo = '';
                if (isNotBlank($("#pageTitleLevelInfoValue").val())) {
                    pageTitleLevelInfo = htmlDecodeEscaptedCharacter($("#pageTitleLevelInfoValue").val());
                    if (isNotBlank(pageTitleLevelInfo))
                        pageTitle = pageTitle + ' ' + pageTitleLevelInfo;
                }
                $('meta[itemprop="name"]').attr('content', pageTitle);
            } catch (e) {}
            try {
                $('meta[itemprop="description"]').attr('content', htmlDecodeEscaptedCharacter($("#metaDescSearchLean").html()));
            } catch (e) {}
            try {
                $('meta[itemprop="priceCurrency"]').attr('content', $("#currencyCodeToDisplayMetaSearchLean").html());
            } catch (e) {}
            try {
                $('meta[itemprop="offerCount"]').attr('content', $("#totalResultsFoundSearchLean").html());
            } catch (e) {}
        } else {
            resetMetaPropForTutorsSearch();
        }
    } catch (e) {
        resetMetaPropForTutorsSearch();
    }
};

var resetMetaPropForTutorsSearch = function() {
    try {
        $('meta[itemprop="name"]').attr('content', '');
    } catch (e) {}
    try {
        $('meta[itemprop="description"]').attr('content', '');
    } catch (e) {}
    try {
        $('meta[itemprop="priceCurrency"]').attr('content', '');
    } catch (e) {}
    try {
        $('meta[itemprop="offerCount"]').attr('content', '');
    } catch (e) {}
};

var createMetaLink = function(relName, hrefValue) {
    var m = document.createElement('link');
    m.rel = relName;
    m.href = hrefValue;
    document.head.appendChild(m);
};

var createMetaTag = function(metaName, metaContent) {
    var m = document.createElement('meta');
    m.name = metaName;
    m.content = metaContent;
    document.head.appendChild(m);
};

// escape html is converting & to &amp; so use this to get the original character
function htmlDecodeEscaptedCharacter(input) {
    var e = document.createElement('textarea');
    e.innerHTML = input;
    // handle case of empty input
    return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
};